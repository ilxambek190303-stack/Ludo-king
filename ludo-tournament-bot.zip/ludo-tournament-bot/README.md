# 🎲 Ludo Tournament Bot

A Telegram Mini App Ludo game (2-4 players) plus a full group tournament
system: registration, auto-matchmaking, scoring, leaderboards, and admin
controls — all running from one Node.js server.

## Project layout (logic and design kept separate on purpose)

```
src/
  game/ludoEngine.js      Pure Ludo rules (dice, movement, capture, win). No Telegram/DB code.
  services/               Tournament, match, player, scoring logic (business rules, DB access).
  bot/                    Telegram bot commands & keyboards (Telegraf).
  api/                    REST routes + Socket.io realtime game server.
  db/                     SQLite schema + connection (persistent storage).
  config/                 Editable defaults (scoring values, env).
  index.js                Starts everything: Express server, Socket.io, the bot.

public/                   The Mini App (the actual game UI) — plain HTML/CSS/JS.
  css/theme.css           <- Edit colors/theme here.
  js/config.js            <- Asset paths, feature toggles.
  assets/                 <- Replace images/sounds here. See public/README-ASSETS.txt.
```

Because these are separated, you can:
- Redesign the game (colors, art, animations) without touching gameplay or bot code.
- Change tournament/scoring rules without touching the game engine.
- Extend bot commands without touching the game.

## 1. Setup

```bash
npm install
cp .env.example .env
```

Edit `.env`:
- `BOT_TOKEN` — get one from [@BotFather](https://t.me/BotFather).
- `PUBLIC_URL` — your server's public HTTPS URL (use [ngrok](https://ngrok.com) for local testing:
  `ngrok http 3000`, then paste the `https://...ngrok-free.app` URL here).
- Leave `BOT_MODE=polling` for local development.

## 2. Run

```bash
npm start
```

This starts the web server (serving the game + API) and the Telegram bot together.

## 3. Configure the Mini App in BotFather

1. Message @BotFather → `/mybots` → your bot → **Bot Settings** → **Menu Button** (or **Configure Mini App**).
2. Set the Mini App URL to your `PUBLIC_URL`.
3. Add the bot to a Telegram group and give it admin rights (needed to read member/admin status for `/create_tournament` etc.).

## 4. Try it

In a group:
- `/create_tournament` (admin) → players tap **Join Tournament**
- `/start_tournament` (admin) → bot posts matches with **Open Ludo Game** buttons
- Players tap the button, the Mini App opens, they play live — results and
  scores are recorded **automatically** when a match finishes.
- `/standings`, `/profile`, `/history` any time.
- Admins can also manually record a result with `/result <matchId> @winner @second ...`
  for matches played outside the app; duplicate submissions are rejected.

Outside a group, `/play` starts a casual (non-tournament) match — useful for
testing the game itself solo or with friends via the room link.

## 5. Admin commands

| Command | Effect |
|---|---|
| `/create_tournament` | Open registration |
| `/start_tournament` | Start round-robin bracket matches |
| `/stop_tournament` | Stop the current tournament |
| `/restart_tournament` | Clear matches, reopen registration |
| `/setscoring <win> <2nd> <3rd> <lose>` | Change point values for the current tournament |
| `/addplayer <name>` | Add a player manually (no Telegram account needed) |
| `/removeplayer @username` | Remove a player's record |
| `/allplayers` | View every player and their stats |
| `/matchhistory` | Full match history |
| `/resetleaderboard` | Wipe all stats for the group |
| `/tournamentstats` | Stats for the current/last tournament |

## 6. Data persistence

Everything (players, matches, tournaments, scores) is stored in a SQLite file
at the path set by `DB_PATH` in `.env` (default `./data/ludo.sqlite`). Back up
that one file to preserve all history. Live in-progress game turns are kept
in server memory only (a match's final result is what gets saved) — if the
server restarts mid-game, that single match would need to be replayed, but
no tournament/score data is lost.

## 7. Roadmap notes (MVP → polish)

This is a working MVP as requested. Good next steps once you're happy with
the mechanics:
- Swap placeholder SVGs/sounds in `public/assets/` (see `public/README-ASSETS.txt`).
- Add reconnect/resume support for a live game after a dropped connection.
- Add a proper visual bracket view for tournaments with 5+ players.
- Verify Telegram `initData` server-side (via `BOT_TOKEN`) for tighter security
  before going to production with real users.
