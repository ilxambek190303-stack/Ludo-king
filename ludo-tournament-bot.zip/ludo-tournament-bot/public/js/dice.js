/**
 * Dice.js — purely presentational. The actual dice VALUE always comes from
 * the server (src/game/ludoEngine.js rollDice), never generated client-side,
 * so results can't be spoofed by editing frontend code.
 */
const Dice = (() => {
  const el = () => document.getElementById('dice-el');
  const rollBtn = () => document.getElementById('roll-btn');
  let onRoll = () => {};

  function init(rollHandler) {
    onRoll = rollHandler;
    rollBtn().addEventListener('click', () => {
      Sound.play('buttonClick');
      onRoll();
    });
  }

  function showRolling() {
    rollBtn().disabled = true;
    Anim.spinDice(el());
  }

  function showResult(value) {
    el().textContent = value;
    rollBtn().disabled = false;
    Sound.play('diceRoll');
  }

  function setEnabled(enabled) {
    rollBtn().disabled = !enabled;
  }

  return { init, showRolling, showResult, setEnabled };
})();
