/**
 * GAME_CONFIG — everything a designer would want to tweak without touching
 * game logic. Swap image files in /public/assets/ and, if you rename files,
 * update the paths below. Colors are also controlled via CSS variables in
 * css/theme.css (that's the easiest place to restyle the board).
 */
const GAME_CONFIG = {
  colors: ['red', 'green', 'yellow', 'blue'],

  images: {
    boardBackground: 'assets/images/board/board-bg.svg',
    tokens: {
      red: 'assets/images/tokens/token-red.svg',
      green: 'assets/images/tokens/token-green.svg',
      yellow: 'assets/images/tokens/token-yellow.svg',
      blue: 'assets/images/tokens/token-blue.svg',
    },
    dice: [
      'assets/images/dice/dice-2.svg',
      'assets/images/dice/dice-4.svg',
      'assets/images/dice/dice-6.svg',
    ],
    starIcon: 'assets/images/icons/star.svg',
    trophyIcon: 'assets/images/icons/trophy.svg',
    rollButton: 'assets/images/buttons/roll-button.svg',
  },

  sounds: {
    diceRoll: 'assets/sounds/dice-roll.mp3',
    tokenMove: 'assets/sounds/token-move.mp3',
    capture: 'assets/sounds/capture.mp3',
    tokenHome: 'assets/sounds/token-home.mp3',
    victory: 'assets/sounds/victory.mp3',
    buttonClick: 'assets/sounds/click.mp3',
  },

  // Master switches a player (or you, while testing) can flip.
  settings: {
    soundEnabled: true,
    animationsEnabled: true,
  },
};
