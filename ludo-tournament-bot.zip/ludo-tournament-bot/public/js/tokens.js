/**
 * Tokens.js — owns the token DOM elements. Rendering is driven entirely by
 * the `tokens` object in server game state ({ red: [pos,pos,pos,pos], ... }),
 * so this file never decides game rules — it only draws and forwards clicks.
 */
const Tokens = (() => {
  const boardEl = () => document.getElementById('board-grid');
  const elements = {}; // "color-index" -> DOM element
  let onTokenClick = () => {};

  function ensureElement(color, index) {
    const key = `${color}-${index}`;
    if (elements[key]) return elements[key];
    const el = document.createElement('div');
    el.className = `token token-${color}`;
    el.dataset.color = color;
    el.dataset.index = index;
    el.addEventListener('click', () => onTokenClick(color, index));
    boardEl().appendChild(el);
    elements[key] = el;
    return el;
  }

  function render(tokensState, { movable = [], myColor = null } = {}) {
    Object.entries(tokensState).forEach(([color, positions]) => {
      positions.forEach((pos, idx) => {
        const el = ensureElement(color, idx);
        const { left, top } = Board.positionFor(color, pos, idx);
        el.style.left = left + '%';
        el.style.top = top + '%';
        const isMovable = color === myColor && movable.includes(idx);
        el.classList.toggle('movable', isMovable);
      });
    });
  }

  function flashCapture(color, index) {
    const el = elements[`${color}-${index}`];
    if (el) Anim.flashCapture(el);
  }

  function setClickHandler(fn) {
    onTokenClick = fn;
  }

  return { render, flashCapture, setClickHandler };
})();
