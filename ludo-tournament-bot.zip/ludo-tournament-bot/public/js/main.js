(function main() {
  const socket = io();
  const params = new URLSearchParams(window.location.search);
  const roomCode = params.get('room');
  // The bot embeds the chat ID in the room link when it makes sense to;
  // fall back gracefully if not present (e.g. direct /play in a DM).
  const chatId = params.get('chat') || TelegramBridge.getChatId();

  let myPlayerId = null;
  let myColor = null;
  let latestState = null;

  const lobbyScreen = document.getElementById('lobby-screen');
  const gameScreen = document.getElementById('game-screen');
  const lobbyPlayersEl = document.getElementById('lobby-players');
  const startBtn = document.getElementById('start-game-btn');
  const turnDot = document.getElementById('turn-dot');
  const turnLabel = document.getElementById('turn-label');
  const youLabel = document.getElementById('you-label');
  const winnerOverlay = document.getElementById('winner-overlay');
  const winnerText = document.getElementById('winner-text');
  const muteBtn = document.getElementById('mute-btn');

  async function init() {
    TelegramBridge.init();
    Board.buildGrid();

    if (!roomCode) {
      Anim.toast('No room code in URL — open this game via the bot.');
      return;
    }

    try {
      const match = await Api.getMatch(roomCode);
      const tgUser = TelegramBridge.getUser();
      const identity = await Api.identify(chatId || 0, tgUser);
      myPlayerId = identity.playerId;

      socket.emit('join_room', { roomCode, playerId: myPlayerId, name: identity.name });
    } catch (err) {
      Anim.toast(err.message);
    }
  }

  socket.on('lobby_update', ({ players, canStart }) => {
    lobbyPlayersEl.innerHTML = '';
    players.forEach((p) => {
      const chip = document.createElement('div');
      chip.className = 'player-chip';
      chip.innerHTML = `<span class="color-dot pip-${p.color}"></span><span>${p.name}${p.playerId === myPlayerId ? ' (you)' : ''}</span>`;
      lobbyPlayersEl.appendChild(chip);
    });
    startBtn.disabled = !canStart;
    startBtn.textContent = canStart ? 'Start Game' : `Start Game (need 2+ players)`;
    const me = players.find((p) => p.playerId === myPlayerId);
    if (me) myColor = me.color;
  });

  startBtn.addEventListener('click', () => {
    Sound.play('buttonClick');
    socket.emit('start_game');
  });

  socket.on('game_state', (state) => {
    latestState = state;
    if (state.status === 'active' || state.status === 'finished') {
      lobbyScreen.classList.add('hidden');
      gameScreen.classList.remove('hidden');
    }
    renderState(state);
  });

  function renderState(state) {
    const me = state.players.find((p) => p.playerId === myPlayerId);
    if (me) myColor = me.color;
    youLabel.textContent = myColor ? `You: ${myColor}` : '';

    turnLabel.textContent = state.turnColor ? capitalize(state.turnColor) + "'s turn" : '—';
    turnDot.className = 'color-dot pip-' + (state.turnColor || 'red');

    Tokens.render(state.tokens, { myColor });
    Dice.setEnabled(state.turnColor === myColor && state.status === 'active');
  }

  Dice.init(() => {
    if (latestState?.turnColor !== myColor) {
      Anim.toast("It's not your turn.");
      return;
    }
    Dice.showRolling();
    socket.emit('roll_dice');
  });

  socket.on('dice_rolled', ({ roll, movable, autoPassed, by }) => {
    Dice.showResult(roll);
    if (by === myPlayerId && autoPassed) {
      Anim.toast('No legal move — turn passed.');
    }
    if (latestState) {
      Tokens.render(latestState.tokens, { movable: by === myPlayerId ? movable : [], myColor });
    }
  });

  Tokens.setClickHandler((color, index) => {
    if (color !== myColor) return;
    if (latestState?.turnColor !== myColor) return;
    socket.emit('move_token', { tokenIndex: index });
  });

  socket.on('token_moved', ({ captured, state }) => {
    Sound.play('tokenMove');
    if (captured) {
      Sound.play('capture');
      Tokens.flashCapture(captured.color, captured.tokenIndex);
      Anim.toast(`${capitalize(captured.color)}'s token was captured!`);
    }
    latestState = state;
    renderState(state);
  });

  socket.on('game_over', ({ ranking }) => {
    Sound.play('victory');
    Anim.confetti();
    TelegramBridge.hapticNotify('success');
    winnerText.innerHTML = ranking
      .map((p, i) => `<div>${i + 1}. ${p.name}</div>`)
      .join('');
    winnerOverlay.classList.remove('hidden');
  });

  document.getElementById('close-overlay-btn').addEventListener('click', () => {
    winnerOverlay.classList.add('hidden');
  });

  socket.on('error_message', (msg) => Anim.toast(msg));

  muteBtn.addEventListener('click', () => {
    const enabled = Sound.toggle();
    muteBtn.textContent = enabled ? '🔊' : '🔇';
  });

  function capitalize(s) {
    return s ? s[0].toUpperCase() + s.slice(1) : s;
  }

  init();
})();
