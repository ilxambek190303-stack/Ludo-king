/**
 * Thin wrapper around Telegram's WebApp SDK so the rest of the app never
 * touches `window.Telegram` directly. If this page is opened outside
 * Telegram (e.g. a normal browser during development), everything here
 * degrades gracefully with mock values.
 */
const TelegramBridge = (() => {
  const tg = window.Telegram?.WebApp || null;

  function init() {
    if (!tg) {
      console.warn('Not running inside Telegram — using mock user for local testing.');
      return;
    }
    tg.ready();
    tg.expand();
    try {
      tg.setHeaderColor('secondary_bg_color');
    } catch (e) {
      /* older clients may not support this */
    }
  }

  function getUser() {
    if (tg?.initDataUnsafe?.user) {
      return tg.initDataUnsafe.user;
    }
    // Fallback for local browser testing outside Telegram.
    const mockId = Math.floor(Math.random() * 1e6);
    return { id: mockId, username: `guest${mockId}`, first_name: 'Guest' };
  }

  function getChatId() {
    // Telegram Mini Apps launched from a group message expose the chat via
    // start_param or initDataUnsafe.chat depending on launch context. As a
    // practical fallback for this MVP, the bot embeds chatId in the room's
    // URL query string (see keyboards.js -> openGameKeyboard), read in main.js.
    return tg?.initDataUnsafe?.chat?.id || null;
  }

  function hapticImpact(style = 'light') {
    tg?.HapticFeedback?.impactOccurred(style);
  }

  function hapticNotify(type = 'success') {
    tg?.HapticFeedback?.notificationOccurred(type);
  }

  function close() {
    tg?.close();
  }

  return { init, getUser, getChatId, hapticImpact, hapticNotify, close, raw: tg };
})();
