/**
 * Board.js — builds the 15x15 Ludo grid and converts a token's *relative*
 * engine position (see src/game/ludoEngine.js) into a percentage-based
 * (row, col) on screen. Kept separate from tokens.js (which owns the actual
 * token DOM elements) and dice.js, so the visual layout can be redesigned
 * without touching movement logic.
 */
const Board = (() => {
  const SIZE = 15;

  // The single shared 52-cell loop, index 0-51. Index 0 must line up with
  // ENTRY_OFFSET.red = 0 in the server engine, 13 with green, 26 yellow, 39
  // blue — this array IS that physical loop, built as four 90°-rotated arms
  // so it's perfectly symmetric.
  const GLOBAL_PATH = [
    [6, 1], [6, 2], [6, 3], [6, 4], [6, 5],
    [5, 6], [4, 6], [3, 6], [2, 6], [1, 6], [0, 6],
    [0, 7],
    [0, 8], [1, 8], [2, 8], [3, 8], [4, 8], [5, 8],
    [6, 9], [6, 10], [6, 11], [6, 12], [6, 13], [6, 14],
    [7, 14],
    [8, 14], [8, 13], [8, 12], [8, 11], [8, 10], [8, 9],
    [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], [14, 8],
    [14, 7],
    [14, 6], [13, 6], [12, 6], [11, 6], [10, 6], [9, 6],
    [8, 5], [8, 4], [8, 3], [8, 2], [8, 1], [8, 0],
    [7, 0],
    [6, 0],
  ];

  // 5 cells each (relative positions 51-55) — matches src/game/ludoEngine.js
  // FINISH=56, which sits at CENTER below. Kept in sync deliberately: since
  // the dice only rolls even numbers, the finish position must be even.
  const HOME_STRETCH = {
    red: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]],
    green: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]],
    yellow: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]],
    blue: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]],
  };

  const CENTER = [7, 7];

  const BASE_SLOTS = {
    red: [[1.5, 1.5], [1.5, 3.5], [3.5, 1.5], [3.5, 3.5]],
    green: [[1.5, 10.5], [1.5, 12.5], [3.5, 10.5], [3.5, 12.5]],
    yellow: [[10.5, 10.5], [10.5, 12.5], [12.5, 10.5], [12.5, 12.5]],
    blue: [[10.5, 1.5], [10.5, 3.5], [12.5, 1.5], [12.5, 3.5]],
  };

  const ENTRY_OFFSET = { red: 0, green: 13, yellow: 26, blue: 39 };
  const SAFE_CELLS = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

  /** Converts an engine relative position (-1..57) for `color` into a [row, col]. */
  function relPosToCell(color, relPos) {
    if (relPos === -1 || relPos == null) return null; // caller should use a base slot instead
    if (relPos <= 50) {
      const abs = (ENTRY_OFFSET[color] + relPos) % 52;
      return GLOBAL_PATH[abs];
    }
    if (relPos <= 55) {
      return HOME_STRETCH[color][relPos - 51];
    }
    return CENTER; // 56 = finished
  }

  function cellToPercent([row, col]) {
    return { left: ((col + 0.5) / SIZE) * 100, top: ((row + 0.5) / SIZE) * 100 };
  }

  function buildGrid() {
    const grid = document.getElementById('board-grid');
    grid.innerHTML = '';

    const pathSet = new Map(); // "row,col" -> {type, colorMaybe}
    GLOBAL_PATH.forEach((cell, idx) => {
      pathSet.set(cell.join(','), { type: SAFE_CELLS.has(idx) ? 'safe' : 'path' });
    });
    Object.entries(HOME_STRETCH).forEach(([color, cells]) => {
      cells.forEach((cell) => pathSet.set(cell.join(','), { type: 'home', color }));
    });
    pathSet.set(CENTER.join(','), { type: 'center' });

    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        const div = document.createElement('div');
        const info = pathSet.get(`${r},${c}`);
        const inRedYard = r < 6 && c < 6;
        const inGreenYard = r < 6 && c > 8;
        const inYellowYard = r > 8 && c > 8;
        const inBlueYard = r > 8 && c < 6;

        if (info?.type === 'safe') div.className = 'cell safe';
        else if (info?.type === 'home') div.className = `cell home-${info.color}`;
        else if (info?.type === 'center') div.className = 'cell center';
        else if (info?.type === 'path') div.className = 'cell path';
        else if (inRedYard) div.className = 'cell base-red';
        else if (inGreenYard) div.className = 'cell base-green';
        else if (inYellowYard) div.className = 'cell base-yellow';
        else if (inBlueYard) div.className = 'cell base-blue';
        else div.className = 'cell path';

        grid.appendChild(div);
      }
    }

    // Base yard slot markers (visual placeholders showing where tokens sit at home).
    Object.entries(BASE_SLOTS).forEach(([color, slots]) => {
      slots.forEach(([row, col]) => {
        const dot = document.createElement('div');
        dot.className = `slot`;
        const pct = cellToPercent([row, col]);
        dot.style.left = pct.left + '%';
        dot.style.top = pct.top + '%';
        dot.style.position = 'absolute';
        dot.style.width = '9%';
        dot.style.height = '9%';
        dot.style.transform = 'translate(-50%, -50%)';
        dot.style.borderRadius = '50%';
        dot.style.background = 'rgba(255,255,255,0.5)';
        grid.appendChild(dot);
      });
    });
  }

  /** Public helper used by tokens.js to know where to place a token. */
  function positionFor(color, relPos, tokenSlotIndex) {
    if (relPos === -1) {
      const [row, col] = BASE_SLOTS[color][tokenSlotIndex];
      return cellToPercent([row, col]);
    }
    return cellToPercent(relPosToCell(color, relPos));
  }

  return { buildGrid, positionFor, SAFE_CELLS, ENTRY_OFFSET };
})();
