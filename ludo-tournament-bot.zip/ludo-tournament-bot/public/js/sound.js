/**
 * Sound.js — tiny wrapper so gameplay code just calls Sound.play('diceRoll').
 * Swap files in /assets/sounds and paths in js/config.js; nothing here needs
 * to change. Fails silently if a file is missing so the game never breaks
 * because of a placeholder asset.
 */
const Sound = (() => {
  let enabled = GAME_CONFIG.settings.soundEnabled;
  const cache = {};

  function get(name) {
    const path = GAME_CONFIG.sounds[name];
    if (!path) return null;
    if (!cache[name]) {
      const audio = new Audio(path);
      audio.volume = 0.6;
      cache[name] = audio;
    }
    return cache[name];
  }

  function play(name) {
    if (!enabled) return;
    const audio = get(name);
    if (!audio) return;
    try {
      audio.currentTime = 0;
      audio.play().catch(() => {});
    } catch (e) {
      /* ignore — placeholder/missing audio file */
    }
  }

  function toggle() {
    enabled = !enabled;
    return enabled;
  }

  function isEnabled() {
    return enabled;
  }

  return { play, toggle, isEnabled };
})();
