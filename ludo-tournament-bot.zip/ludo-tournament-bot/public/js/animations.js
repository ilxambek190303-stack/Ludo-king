const Anim = (() => {
  function toast(message, ms = 2200) {
    const el = document.getElementById('toast');
    el.textContent = message;
    el.classList.remove('hidden');
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.classList.add('hidden'), ms);
  }

  function spinDice(diceEl, cb) {
    if (!GAME_CONFIG.settings.animationsEnabled) return cb?.();
    diceEl.classList.remove('rolling');
    // Force reflow so the animation restarts every roll.
    void diceEl.offsetWidth;
    diceEl.classList.add('rolling');
    diceEl.addEventListener('animationend', function handler() {
      diceEl.classList.remove('rolling');
      diceEl.removeEventListener('animationend', handler);
      cb?.();
    });
  }

  function flashCapture(tokenEl) {
    if (!GAME_CONFIG.settings.animationsEnabled) return;
    tokenEl.classList.remove('captured-flash');
    void tokenEl.offsetWidth;
    tokenEl.classList.add('captured-flash');
  }

  // Minimal confetti burst using plain DOM + CSS, no external library —
  // keeps the "no copyrighted assets / easy to replace" requirement simple.
  function confetti() {
    if (!GAME_CONFIG.settings.animationsEnabled) return;
    const colors = ['#ef4444', '#22c55e', '#eab308', '#3b82f6', '#8b5cf6'];
    for (let i = 0; i < 60; i++) {
      const piece = document.createElement('div');
      piece.style.position = 'fixed';
      piece.style.left = Math.random() * 100 + 'vw';
      piece.style.top = '-10px';
      piece.style.width = '8px';
      piece.style.height = '8px';
      piece.style.background = colors[Math.floor(Math.random() * colors.length)];
      piece.style.opacity = '0.9';
      piece.style.zIndex = 200;
      piece.style.borderRadius = '2px';
      piece.style.transition = `transform ${1.2 + Math.random()}s ease-in, opacity 1.5s ease-in`;
      document.body.appendChild(piece);
      requestAnimationFrame(() => {
        piece.style.transform = `translateY(${100 + Math.random() * 20}vh) rotate(${Math.random() * 720}deg)`;
        piece.style.opacity = '0';
      });
      setTimeout(() => piece.remove(), 2500);
    }
  }

  return { toast, spinDice, flashCapture, confetti };
})();
