const Api = {
  async getMatch(roomCode) {
    const res = await fetch(`/api/match/${roomCode}`);
    if (!res.ok) throw new Error('Match not found');
    return res.json();
  },
  async identify(chatId, telegramUser) {
    const res = await fetch('/api/identify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId, telegramUser }),
    });
    if (!res.ok) throw new Error('Could not identify player');
    return res.json();
  },
};
