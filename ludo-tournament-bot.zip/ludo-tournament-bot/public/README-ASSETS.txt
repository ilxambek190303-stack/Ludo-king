HOW TO RESTYLE THIS GAME (no code changes needed for most of this)
====================================================================

1. COLORS / THEME
   Edit: public/css/theme.css
   Change the CSS variables at the top (--color-red, --bg-primary, etc).
   Every other file reads colors from here — nothing is hardcoded elsewhere.

2. IMAGES
   Replace files (keep the same filenames, or update the paths in
   public/js/config.js if you rename them):
     assets/images/board/board-bg.svg     -> board background art
     assets/images/tokens/token-*.svg     -> the 4 token pieces
     assets/images/dice/dice-2/4/6.svg    -> dice faces
     assets/images/icons/star.svg         -> safe-cell marker
     assets/images/icons/trophy.svg       -> used in leaderboard/winner UI
     assets/images/buttons/roll-button.svg-> optional custom roll button art

   NOTE: by default tokens/dice are drawn with CSS (colored circles /
   numbers) for a clean placeholder look. To use your own PNG/SVG art
   instead, point an <img> or background-image at the paths in
   public/js/config.js — this only requires touching tokens.js/dice.js's
   rendering, never the game rules.

3. SOUNDS
   Drop mp3/ogg files into assets/sounds/ using the filenames referenced
   in public/js/config.js (dice-roll.mp3, token-move.mp3, capture.mp3,
   token-home.mp3, victory.mp3, click.mp3). Missing files fail silently.

4. LAYOUT / ANIMATIONS
   Edit public/css/style.css for spacing, sizing, animation timing.
   Edit public/js/animations.js for the confetti/flash/spin effects.

None of the above requires touching:
   src/game/ludoEngine.js   (game rules)
   src/services/*           (tournament + scoring logic)
   src/bot/*                (Telegram bot commands)
