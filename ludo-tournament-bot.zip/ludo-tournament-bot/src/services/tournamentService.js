const db = require('../db/database');
const matchService = require('./matchService');
const playerService = require('./playerService');
const scoring = require('../config/scoring');

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function createTournament(chatId, adminId, overrides = {}) {
  const existing = getActiveTournament(chatId);
  if (existing) throw new Error('A tournament is already in progress or open for registration in this group.');

  const info = db
    .prepare(
      `INSERT INTO tournaments (chat_id, created_by, status, win_points, second_points, third_points, lose_points)
       VALUES (?, ?, 'registration', ?, ?, ?, ?)`
    )
    .run(
      chatId,
      adminId,
      overrides.win ?? scoring.DEFAULT_WIN_POINTS,
      overrides.second ?? scoring.DEFAULT_SECOND_POINTS,
      overrides.third ?? scoring.DEFAULT_THIRD_POINTS,
      overrides.lose ?? scoring.DEFAULT_LOSE_POINTS
    );
  return getTournament(info.lastInsertRowid);
}

function getTournament(id) {
  return db.prepare('SELECT * FROM tournaments WHERE id = ?').get(id);
}

function getActiveTournament(chatId) {
  return db
    .prepare(
      `SELECT * FROM tournaments WHERE chat_id = ? AND status IN ('registration', 'active') ORDER BY id DESC LIMIT 1`
    )
    .get(chatId);
}

function setPointValues(tournamentId, { win, second, third, lose }) {
  db.prepare(
    `UPDATE tournaments SET win_points = COALESCE(?, win_points), second_points = COALESCE(?, second_points),
     third_points = COALESCE(?, third_points), lose_points = COALESCE(?, lose_points) WHERE id = ?`
  ).run(win, second, third, lose, tournamentId);
  return getTournament(tournamentId);
}

function pointsTableFor(tournament) {
  return {
    win: tournament.win_points,
    second: tournament.second_points,
    third: tournament.third_points,
    lose: tournament.lose_points,
  };
}

function joinTournament(tournamentId, playerId) {
  const t = getTournament(tournamentId);
  if (!t) throw new Error('Tournament not found.');
  if (t.status !== 'registration') throw new Error('Registration is closed for this tournament.');
  db.prepare(`INSERT OR IGNORE INTO tournament_players (tournament_id, player_id) VALUES (?, ?)`).run(
    tournamentId,
    playerId
  );
  return listRegistered(tournamentId);
}

function removeFromTournament(tournamentId, playerId) {
  db.prepare(`DELETE FROM tournament_players WHERE tournament_id = ? AND player_id = ?`).run(
    tournamentId,
    playerId
  );
}

function listRegistered(tournamentId) {
  return db
    .prepare(
      `SELECT p.* FROM tournament_players tp JOIN players p ON p.id = tp.player_id
       WHERE tp.tournament_id = ? ORDER BY tp.joined_at ASC`
    )
    .all(tournamentId);
}

/**
 * Starts the tournament: takes all registered players, shuffles them,
 * and automatically creates round-1 matches of up to 4 players each
 * (Ludo supports 2-4 players per match).
 */
function startTournament(tournamentId) {
  const t = getTournament(tournamentId);
  if (!t) throw new Error('Tournament not found.');
  if (t.status !== 'registration') throw new Error('Tournament already started or finished.');

  const registered = listRegistered(tournamentId);
  if (registered.length < 2) throw new Error('Need at least 2 registered players to start.');

  db.prepare(`UPDATE tournaments SET status = 'active' WHERE id = ?`).run(tournamentId);
  const matches = generateRoundMatches(t.chat_id, tournamentId, shuffle(registered.map((p) => p.id)));
  return matches;
}

function generateRoundMatches(chatId, tournamentId, playerIdPool) {
  const groups = [];
  let i = 0;
  while (i < playerIdPool.length) {
    // Prefer groups of 4; if a leftover of 1 would result, fold it into the previous group (max 4).
    let size = Math.min(4, playerIdPool.length - i);
    if (playerIdPool.length - i === 5) size = 3; // 3+2 instead of 4+1
    groups.push(playerIdPool.slice(i, i + size));
    i += size;
  }
  return groups.map((ids) => matchService.createMatch({ chatId, tournamentId, playerIds: ids }));
}

/**
 * Call after a tournament match's result is recorded. If every match in the
 * current round is finished, either advances winners to a new round, or —
 * if only one player is left — finishes the tournament.
 */
function progressAfterMatch(tournamentId) {
  const t = getTournament(tournamentId);
  if (!t || t.status !== 'active') return null;

  const allMatches = matchService.tournamentMatches(tournamentId);
  const latestRoundMatches = getLatestRound(allMatches);
  const unfinished = latestRoundMatches.filter((m) => m.status !== 'finished');
  if (unfinished.length > 0) return null; // round still in progress

  const winners = latestRoundMatches.map((m) => m.ranking[0]);

  if (winners.length === 1) {
    const winnerId = winners[0];
    db.prepare(
      `UPDATE tournaments SET status = 'finished', finished_at = datetime('now'), winner_player_id = ? WHERE id = ?`
    ).run(winnerId, tournamentId);
    db.prepare('UPDATE players SET tournament_wins = tournament_wins + 1 WHERE id = ?').run(winnerId);
    return { finished: true, winnerId };
  }

  const nextMatches = generateRoundMatches(t.chat_id, tournamentId, shuffle(winners));
  return { finished: false, nextMatches };
}

function getLatestRound(allMatches) {
  if (allMatches.length === 0) return [];
  // Matches created together share creation order; treat the highest-id
  // contiguous block whose players don't overlap with earlier blocks as the round.
  // Simpler: group by whether they were finished together — we track rounds
  // implicitly by re-deriving from remaining unresolved matches.
  const unresolved = allMatches.filter((m) => m.status !== 'finished');
  if (unresolved.length > 0) {
    const minId = Math.min(...unresolved.map((m) => m.id));
    // The round = all matches created at/after the earliest still-open match,
    // i.e. everything from that point forward that hasn't been superseded.
    return allMatches.filter((m) => m.id >= minId);
  }
  // Everything finished — the "latest round" is the set of matches created
  // after the second-to-last distinct id gap. Fallback: last match only.
  return [allMatches[allMatches.length - 1]];
}

function stopTournament(tournamentId) {
  db.prepare(`UPDATE tournaments SET status = 'stopped', finished_at = datetime('now') WHERE id = ?`).run(
    tournamentId
  );
}

function restartTournament(tournamentId) {
  const t = getTournament(tournamentId);
  if (!t) throw new Error('Tournament not found.');
  db.prepare(`DELETE FROM matches WHERE tournament_id = ?`).run(tournamentId);
  db.prepare(`UPDATE tournaments SET status = 'registration', winner_player_id = NULL, finished_at = NULL WHERE id = ?`).run(
    tournamentId
  );
  return getTournament(tournamentId);
}

function history(chatId, limit = 10) {
  return db
    .prepare(`SELECT * FROM tournaments WHERE chat_id = ? ORDER BY id DESC LIMIT ?`)
    .all(chatId, limit);
}

module.exports = {
  createTournament,
  getTournament,
  getActiveTournament,
  setPointValues,
  pointsTableFor,
  joinTournament,
  removeFromTournament,
  listRegistered,
  startTournament,
  progressAfterMatch,
  stopTournament,
  restartTournament,
  history,
};
