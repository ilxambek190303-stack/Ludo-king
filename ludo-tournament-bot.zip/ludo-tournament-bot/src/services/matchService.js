const db = require('../db/database');
const { nanoid } = require('nanoid');
const scoreService = require('./scoreService');

function createMatch({ chatId, tournamentId = null, playerIds }) {
  const roomCode = nanoid(8);
  const info = db
    .prepare(
      `INSERT INTO matches (tournament_id, chat_id, room_code, status, player_ids)
       VALUES (?, ?, ?, 'pending', ?)`
    )
    .run(tournamentId, chatId, roomCode, JSON.stringify(playerIds));
  return getMatch(info.lastInsertRowid);
}

function getMatch(id) {
  const row = db.prepare('SELECT * FROM matches WHERE id = ?').get(id);
  if (!row) return null;
  return {
    ...row,
    player_ids: JSON.parse(row.player_ids),
    ranking: row.ranking ? JSON.parse(row.ranking) : null,
  };
}

function getMatchByRoomCode(roomCode) {
  const row = db.prepare('SELECT * FROM matches WHERE room_code = ?').get(roomCode);
  if (!row) return null;
  return getMatch(row.id);
}

function setActive(matchId) {
  db.prepare(`UPDATE matches SET status = 'active' WHERE id = ? AND status = 'pending'`).run(matchId);
}

/**
 * Records the final ranking (array of player_id, winner first) for a match.
 * Throws if the match is already finished — this is the duplicate-result guard.
 */
function recordResult(matchId, ranking, pointsTable) {
  const match = getMatch(matchId);
  if (!match) throw new Error('Match not found.');
  if (match.status === 'finished') {
    throw new Error('Result already recorded for this match — duplicate submissions are not allowed.');
  }

  const validIds = new Set(match.player_ids);
  if (ranking.length !== match.player_ids.length || !ranking.every((id) => validIds.has(id))) {
    throw new Error('Ranking must contain exactly the players who were in this match.');
  }

  db.prepare(
    `UPDATE matches SET status = 'finished', ranking = ?, finished_at = datetime('now') WHERE id = ?`
  ).run(JSON.stringify(ranking), matchId);

  scoreService.applyMatchResult({ ranking, pointsTable });

  return getMatch(matchId);
}

function history(chatId, limit = 20) {
  return db
    .prepare(
      `SELECT * FROM matches WHERE chat_id = ? AND status = 'finished'
       ORDER BY finished_at DESC LIMIT ?`
    )
    .all(chatId, limit)
    .map((row) => ({ ...row, player_ids: JSON.parse(row.player_ids), ranking: JSON.parse(row.ranking) }));
}

function tournamentMatches(tournamentId) {
  return db
    .prepare('SELECT * FROM matches WHERE tournament_id = ? ORDER BY id ASC')
    .all(tournamentId)
    .map((row) => ({
      ...row,
      player_ids: JSON.parse(row.player_ids),
      ranking: row.ranking ? JSON.parse(row.ranking) : null,
    }));
}

module.exports = {
  createMatch,
  getMatch,
  getMatchByRoomCode,
  setActive,
  recordResult,
  history,
  tournamentMatches,
};
