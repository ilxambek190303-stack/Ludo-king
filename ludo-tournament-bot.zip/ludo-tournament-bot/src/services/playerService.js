const db = require('../db/database');

function getOrCreatePlayer(chatId, telegramUser) {
  const existing = db
    .prepare('SELECT * FROM players WHERE chat_id = ? AND telegram_id = ?')
    .get(chatId, telegramUser.id);
  if (existing) {
    // Keep username/first_name fresh in case they changed it.
    db.prepare('UPDATE players SET username = ?, first_name = ? WHERE id = ?').run(
      telegramUser.username || null,
      telegramUser.first_name || null,
      existing.id
    );
    return { ...existing, username: telegramUser.username || existing.username };
  }
  const info = db
    .prepare(
      `INSERT INTO players (chat_id, telegram_id, username, first_name)
       VALUES (?, ?, ?, ?)`
    )
    .run(chatId, telegramUser.id, telegramUser.username || null, telegramUser.first_name || null);
  return db.prepare('SELECT * FROM players WHERE id = ?').get(info.lastInsertRowid);
}

function getPlayerById(playerId) {
  return db.prepare('SELECT * FROM players WHERE id = ?').get(playerId);
}

function getPlayerByTelegramId(chatId, telegramId) {
  return db.prepare('SELECT * FROM players WHERE chat_id = ? AND telegram_id = ?').get(chatId, telegramId);
}

function listPlayers(chatId) {
  return db.prepare('SELECT * FROM players WHERE chat_id = ? ORDER BY points DESC').all(chatId);
}

function removePlayer(chatId, telegramId) {
  return db.prepare('DELETE FROM players WHERE chat_id = ? AND telegram_id = ?').run(chatId, telegramId);
}

function addManualPlayer(chatId, fakeTelegramId, name) {
  const info = db
    .prepare(`INSERT OR IGNORE INTO players (chat_id, telegram_id, username, first_name) VALUES (?, ?, ?, ?)`)
    .run(chatId, fakeTelegramId, null, name);
  return db.prepare('SELECT * FROM players WHERE chat_id = ? AND telegram_id = ?').get(chatId, fakeTelegramId);
}

function resetLeaderboard(chatId) {
  return db
    .prepare(
      `UPDATE players SET games_played = 0, wins = 0, losses = 0, points = 0, tournament_wins = 0
       WHERE chat_id = ?`
    )
    .run(chatId);
}

function displayName(player) {
  return player.username ? `@${player.username}` : player.first_name || `Player#${player.id}`;
}

module.exports = {
  getOrCreatePlayer,
  getPlayerById,
  getPlayerByTelegramId,
  listPlayers,
  removePlayer,
  addManualPlayer,
  resetLeaderboard,
  displayName,
};
