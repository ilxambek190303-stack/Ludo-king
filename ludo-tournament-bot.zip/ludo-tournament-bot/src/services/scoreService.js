const db = require('../db/database');

/**
 * Applies points for a finished match's ranking to all involved players,
 * and bumps games_played/wins/losses. `ranking` is an array of player_id
 * ordered 1st -> last. `pointsTable` = { win, second, third, lose }.
 */
function applyMatchResult({ ranking, pointsTable }) {
  const applyOne = db.prepare(
    `UPDATE players
     SET games_played = games_played + 1,
         wins = wins + ?,
         losses = losses + ?,
         points = points + ?
     WHERE id = ?`
  );

  const tx = db.transaction((ranking) => {
    ranking.forEach((playerId, idx) => {
      let pts;
      let isWin = 0;
      let isLoss = 0;
      if (idx === 0) {
        pts = pointsTable.win;
        isWin = 1;
      } else if (idx === 1) {
        pts = pointsTable.second;
        isLoss = 1;
      } else if (idx === 2) {
        pts = pointsTable.third;
        isLoss = 1;
      } else {
        pts = pointsTable.lose;
        isLoss = 1;
      }
      applyOne.run(isWin, isLoss, pts, playerId);
    });
  });

  tx(ranking);
}

function winRate(player) {
  if (!player.games_played) return 0;
  return Math.round((player.wins / player.games_played) * 1000) / 10; // one decimal
}

module.exports = { applyMatchResult, winRate };
