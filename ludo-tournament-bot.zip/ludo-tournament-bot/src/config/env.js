require('dotenv').config();

module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN || '',
  PUBLIC_URL: process.env.PUBLIC_URL || '',
  BOT_MODE: process.env.BOT_MODE || 'polling',
  PORT: parseInt(process.env.PORT || '3000', 10),
  DB_PATH: process.env.DB_PATH || './data/ludo.sqlite',
  WEBAPP_PATH: process.env.WEBAPP_PATH || '/',
};
