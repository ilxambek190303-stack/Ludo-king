// Default point values used when a NEW tournament is created.
// Admins can override these per-tournament with /setscoring (see bot/commands/admin.js),
// which updates the tournament's row in the database — this file only controls the defaults.
module.exports = {
  DEFAULT_WIN_POINTS: 10,
  DEFAULT_SECOND_POINTS: 6,
  DEFAULT_THIRD_POINTS: 3,
  DEFAULT_LOSE_POINTS: 1,

  // Ludo game rule constants (kept here, separate from bot/tournament logic,
  // so gameplay tuning never touches tournament code).
  DICE_FACES: [2, 4, 6],
  TOKENS_PER_PLAYER: 4,
  MAX_CONSECUTIVE_SIXES: 3, // safety cap to avoid infinite extra turns
};
