const path = require('path');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const { PORT, BOT_TOKEN, BOT_MODE, PUBLIC_URL } = require('./config/env');
const apiRoutes = require('./api/routes');
const attachSocketServer = require('./api/socket');
const bot = require('./bot/bot');

const app = express();
app.use(cors());
app.use(express.json());

// The Mini App (game) is plain static files — swap anything under /public
// (see public/README-ASSETS.txt) without touching any server code.
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api', apiRoutes);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
attachSocketServer(io, bot);

server.listen(PORT, () => {
  console.log(`✅ Server + Mini App running on port ${PORT}`);
  if (PUBLIC_URL) console.log(`   Public URL: ${PUBLIC_URL}`);
});

if (BOT_TOKEN) {
  if (BOT_MODE === 'webhook' && PUBLIC_URL) {
    const webhookPath = `/telegraf/${BOT_TOKEN}`;
    app.use(bot.webhookCallback(webhookPath));
    bot.telegram.setWebhook(`${PUBLIC_URL}${webhookPath}`);
    console.log('🤖 Bot running in webhook mode at', webhookPath);
  } else {
    bot.launch();
    console.log('🤖 Bot running in polling mode');
  }
} else {
  console.log('🤖 Bot NOT started — set BOT_TOKEN in .env to enable it.');
}

process.once('SIGINT', () => {
  bot.stop('SIGINT');
  process.exit(0);
});
process.once('SIGTERM', () => {
  bot.stop('SIGTERM');
  process.exit(0);
});
