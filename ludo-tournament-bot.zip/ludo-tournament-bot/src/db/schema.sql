-- Players are scoped per Telegram group (chat_id) so the same person
-- can have independent stats in different groups.
CREATE TABLE IF NOT EXISTS players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER NOT NULL,
  telegram_id INTEGER NOT NULL,
  username TEXT,
  first_name TEXT,
  games_played INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  points INTEGER NOT NULL DEFAULT 0,
  tournament_wins INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(chat_id, telegram_id)
);

CREATE TABLE IF NOT EXISTS tournaments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'registration', -- registration | active | finished | stopped
  created_by INTEGER NOT NULL,
  win_points INTEGER NOT NULL DEFAULT 10,
  second_points INTEGER NOT NULL DEFAULT 6,
  third_points INTEGER NOT NULL DEFAULT 3,
  lose_points INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT,
  winner_player_id INTEGER
);

CREATE TABLE IF NOT EXISTS tournament_players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER NOT NULL,
  player_id INTEGER NOT NULL,
  joined_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(tournament_id, player_id)
);

CREATE TABLE IF NOT EXISTS matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER,
  chat_id INTEGER NOT NULL,
  room_code TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | active | finished
  player_ids TEXT NOT NULL, -- JSON array of player_id, in join/turn order
  ranking TEXT, -- JSON array of player_id in finishing order (1st..last), set once
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_players_chat ON players(chat_id);
CREATE INDEX IF NOT EXISTS idx_matches_tournament ON matches(tournament_id);
CREATE INDEX IF NOT EXISTS idx_tp_tournament ON tournament_players(tournament_id);
