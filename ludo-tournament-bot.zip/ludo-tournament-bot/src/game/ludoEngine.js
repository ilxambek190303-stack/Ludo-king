/**
 * Ludo game engine — pure game logic, no Telegram/DB/HTTP dependencies.
 * This is the single source of truth for game rules. The frontend (public/js/*)
 * never decides outcomes; it only renders state pushed from here via socket.io
 * (see src/api/socket.js) and sends player *intents* (roll / move token X).
 *
 * Board model:
 *  - There is one shared 52-cell outer loop (indices 0..51).
 *  - Each color has a fixed entry index onto that loop.
 *  - Each color also has a private 6-cell "home stretch" (indices 52..57 in
 *    that color's own relative track) that only that color's tokens use,
 *    followed by a "finished" slot (index 57).
 *  - A token's position is stored as an integer 0..57 on ITS OWN relative
 *    track (0 = just left base, 51 = last shared cell before turning into
 *    the home stretch, 52-56 = home stretch, 57 = finished), or -1 = in base.
 *  - To know if two tokens of different colors are on the same physical cell,
 *    we convert a relative position (0-51 range only) to an absolute loop
 *    index using each color's ENTRY_OFFSET.
 */

const COLORS = ['red', 'green', 'yellow', 'blue'];

// Where each color enters the shared 52-cell loop (classic Ludo layout).
const ENTRY_OFFSET = { red: 0, green: 13, yellow: 26, blue: 39 };

// Absolute loop cells that are "safe" (star cells + each color's entry cell).
// A token sitting here can never be captured.
const SAFE_CELLS = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

const TRACK_LENGTH = 51; // shared-loop steps before entering home stretch (0..50)
const HOME_STRETCH_START = 51; // relative index 51..55 = home stretch (5 cells)
// IMPORTANT: the dice only produces even numbers (2/4/6) and a token always
// leaves base at relative position 0 (even), so every reachable position is
// even. FINISH must therefore be an even number or it can never be landed on
// exactly — 56 keeps the classic Ludo total of 57 cells per color (51 shared
// + 5 home-stretch + 1 finish), indices 0..56.
const FINISH = 56;

function relativeToAbsolute(color, relPos) {
  // Only meaningful while the token is still on the shared loop (0..50).
  if (relPos < 0 || relPos > 50) return null;
  return (ENTRY_OFFSET[color] + relPos) % 52;
}

function rollDice() {
  const faces = [2, 4, 6];
  return faces[Math.floor(Math.random() * faces.length)];
}

/**
 * Creates a fresh game state for a list of players.
 * players: [{ playerId, color }]
 */
function createGame(players) {
  const tokens = {};
  for (const p of players) {
    tokens[p.color] = [-1, -1, -1, -1]; // 4 tokens, all in base
  }
  return {
    players, // [{playerId, color}]
    tokens, // { color: [pos, pos, pos, pos] }
    turnIndex: 0, // index into players[]
    diceValue: null,
    consecutiveSixes: 0,
    mustMoveAfterRoll: false,
    finishedOrder: [], // playerIds in the order they finished all 4 tokens
    status: 'active', // active | finished
    winner: null,
    log: [],
  };
}

function currentPlayer(state) {
  return state.players[state.turnIndex];
}

function tokensFinished(state, color) {
  return state.tokens[color].filter((p) => p === FINISH).length;
}

function isPlayerDone(state, color) {
  return tokensFinished(state, color) === 4;
}

/** Returns array of token indices [0-3] that are legally movable with the given roll. */
function getMovableTokens(state, color, roll) {
  const movable = [];
  const positions = state.tokens[color];
  for (let i = 0; i < 4; i++) {
    const pos = positions[i];
    if (pos === FINISH) continue; // already home
    if (pos === -1) {
      if (roll === 6) movable.push(i); // can leave base only on a 6
      continue;
    }
    const newPos = pos + roll;
    if (newPos > FINISH) continue; // overshoot past finish not allowed
    movable.push(i);
  }
  return movable;
}

/**
 * Applies a dice roll for the current player. Returns { movable: [...] , autoPassed }.
 * If there are no movable tokens, the turn auto-passes.
 */
function applyRoll(state) {
  const player = currentPlayer(state);
  const roll = rollDice();
  state.diceValue = roll;

  if (roll === 6) {
    state.consecutiveSixes += 1;
  } else {
    state.consecutiveSixes = 0;
  }

  const movable = getMovableTokens(state, player.color, roll);

  // Three 6's in a row forfeits the turn (standard safety rule).
  if (roll === 6 && state.consecutiveSixes >= 3) {
    state.log.push(`${player.color} rolled three 6's in a row — turn forfeited.`);
    endTurn(state, { forceAdvance: true });
    return { roll, movable: [], autoPassed: true, forfeited: true };
  }

  if (movable.length === 0) {
    state.log.push(`${player.color} rolled ${roll} — no legal move.`);
    endTurn(state, { grantedBySix: roll === 6 });
    return { roll, movable: [], autoPassed: true };
  }

  state.mustMoveAfterRoll = true;
  return { roll, movable, autoPassed: false };
}

/**
 * Moves tokenIndex for the current player by state.diceValue.
 * Handles: leaving base, capturing, entering home stretch, finishing, extra turn on 6.
 */
function moveToken(state, tokenIndex) {
  const player = currentPlayer(state);
  const color = player.color;
  const roll = state.diceValue;
  if (roll == null) throw new Error('No active roll to apply.');

  const positions = state.tokens[color];
  const pos = positions[tokenIndex];
  let captured = null;

  if (pos === -1) {
    if (roll !== 6) throw new Error('Can only leave base on a roll of 6.');
    positions[tokenIndex] = 0;
  } else {
    const newPos = pos + roll;
    if (newPos > FINISH) throw new Error('Move overshoots finish.');
    positions[tokenIndex] = newPos;

    // Capture check only applies while still on the shared loop.
    if (newPos <= 50) {
      const abs = relativeToAbsolute(color, newPos);
      if (!SAFE_CELLS.has(abs)) {
        for (const otherColor of COLORS) {
          if (otherColor === color) continue;
          if (!state.tokens[otherColor]) continue;
          state.tokens[otherColor].forEach((oPos, oIdx) => {
            if (oPos >= 0 && oPos <= 50 && relativeToAbsolute(otherColor, oPos) === abs) {
              state.tokens[otherColor][oIdx] = -1; // sent back to base
              captured = { color: otherColor, tokenIndex: oIdx };
            }
          });
        }
      }
    }
  }

  state.log.push(
    `${color} moved token ${tokenIndex} to ${positions[tokenIndex]}` +
      (captured ? ` and captured ${captured.color}'s token ${captured.tokenIndex}` : '')
  );

  const finishedNow = isPlayerDone(state, color);
  if (finishedNow && !state.finishedOrder.includes(player.playerId)) {
    state.finishedOrder.push(player.playerId);
  }

  // Game ends when only one player remains un-finished (or all finish).
  const remainingPlayers = state.players.filter((p) => !state.finishedOrder.includes(p.playerId));
  if (remainingPlayers.length <= 1 && state.players.length > 1 && state.finishedOrder.length >= state.players.length - 1) {
    // add the last remaining player to the end of the finish order
    remainingPlayers.forEach((p) => {
      if (!state.finishedOrder.includes(p.playerId)) state.finishedOrder.push(p.playerId);
    });
    state.status = 'finished';
    state.winner = state.finishedOrder[0];
  } else if (state.finishedOrder.length === state.players.length) {
    state.status = 'finished';
    state.winner = state.finishedOrder[0];
  }

  const grantedExtraTurn = roll === 6 && state.status !== 'finished';
  state.mustMoveAfterRoll = false;
  endTurn(state, { grantedBySix: grantedExtraTurn });

  return { captured, finishedNow, state };
}

function endTurn(state, { grantedBySix = false, forceAdvance = false } = {}) {
  if (state.status === 'finished') return;
  state.diceValue = null;

  if (grantedBySix && !forceAdvance) {
    // Same player rolls again — do not advance turnIndex.
    return;
  }
  state.consecutiveSixes = 0;

  // Advance to the next player who hasn't finished yet.
  let attempts = 0;
  do {
    state.turnIndex = (state.turnIndex + 1) % state.players.length;
    attempts += 1;
  } while (
    state.finishedOrder.includes(state.players[state.turnIndex].playerId) &&
    attempts <= state.players.length
  );
}

module.exports = {
  COLORS,
  ENTRY_OFFSET,
  SAFE_CELLS,
  TRACK_LENGTH,
  HOME_STRETCH_START,
  FINISH,
  rollDice,
  createGame,
  currentPlayer,
  getMovableTokens,
  applyRoll,
  moveToken,
  relativeToAbsolute,
  isPlayerDone,
};
