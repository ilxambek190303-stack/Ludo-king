const express = require('express');
const matchService = require('../services/matchService');
const playerService = require('../services/playerService');

const router = express.Router();

// Basic info needed by the webapp to render the lobby before the game starts.
router.get('/match/:roomCode', (req, res) => {
  const match = matchService.getMatchByRoomCode(req.params.roomCode);
  if (!match) return res.status(404).json({ error: 'Match not found' });
  const players = match.player_ids.map((id) => {
    const p = playerService.getPlayerById(id);
    return { id: p.id, name: playerService.displayName(p) };
  });
  res.json({
    id: match.id,
    roomCode: match.room_code,
    status: match.status,
    players,
    tournamentId: match.tournament_id,
  });
});

// Player identifies itself to the backend using Telegram WebApp user data
// (sent from the frontend after Telegram.WebApp.initDataUnsafe.user is read).
router.post('/identify', (req, res) => {
  const { chatId, telegramUser } = req.body || {};
  if (!chatId || !telegramUser?.id) return res.status(400).json({ error: 'chatId and telegramUser required' });
  const player = playerService.getOrCreatePlayer(chatId, telegramUser);
  res.json({ playerId: player.id, name: playerService.displayName(player) });
});

module.exports = router;
