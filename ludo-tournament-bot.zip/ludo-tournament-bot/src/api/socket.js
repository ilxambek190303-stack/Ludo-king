const ludo = require('../game/ludoEngine');
const matchService = require('../services/matchService');
const tournamentService = require('../services/tournamentService');
const playerService = require('../services/playerService');

// In-memory live sessions, keyed by roomCode. Persistent results are written
// to the database only once a match finishes (see finalizeMatch below) — the
// live turn-by-turn state itself is ephemeral and does not need to survive
// a server restart.
const sessions = new Map();

function getOrCreateSession(roomCode, match) {
  if (!sessions.has(roomCode)) {
    sessions.set(roomCode, { match, sockets: new Map(), joinOrder: [], engineState: null });
  }
  return sessions.get(roomCode);
}

function publicState(session) {
  if (!session.engineState) return null;
  const s = session.engineState;
  return {
    tokens: s.tokens,
    turnColor: ludo.currentPlayer(s)?.color,
    diceValue: s.diceValue,
    status: s.status,
    finishedOrder: s.finishedOrder,
    players: session.joinOrder.map((j) => ({ playerId: j.playerId, name: j.name, color: j.color })),
  };
}

function attachSocketServer(io, bot) {
  io.on('connection', (socket) => {
    socket.on('join_room', ({ roomCode, playerId, name }) => {
      const match = matchService.getMatchByRoomCode(roomCode);
      if (!match) return socket.emit('error_message', 'Room not found.');
      if (match.status === 'finished') return socket.emit('error_message', 'This match already finished.');

      const session = getOrCreateSession(roomCode, match);
      if (session.joinOrder.length >= 4 && !session.joinOrder.find((j) => j.playerId === playerId)) {
        return socket.emit('error_message', 'This match already has 4 players.');
      }

      socket.join(roomCode);
      socket.data.roomCode = roomCode;
      socket.data.playerId = playerId;

      if (!session.joinOrder.find((j) => j.playerId === playerId)) {
        const usedColors = new Set(session.joinOrder.map((j) => j.color));
        const color = ludo.COLORS.find((c) => !usedColors.has(c));
        session.joinOrder.push({ playerId, name, color, socketId: socket.id });
      }
      session.sockets.set(playerId, socket.id);

      io.to(roomCode).emit('lobby_update', {
        players: session.joinOrder.map((j) => ({ playerId: j.playerId, name: j.name, color: j.color })),
        canStart: session.joinOrder.length >= 2,
      });

      // If a game is already running, catch this socket up.
      if (session.engineState) socket.emit('game_state', publicState(session));
    });

    socket.on('start_game', () => {
      const { roomCode } = socket.data;
      const session = sessions.get(roomCode);
      if (!session) return;
      if (session.engineState) return; // already started
      if (session.joinOrder.length < 2) return socket.emit('error_message', 'Need at least 2 players.');

      session.engineState = ludo.createGame(
        session.joinOrder.map((j) => ({ playerId: j.playerId, color: j.color }))
      );
      matchService.setActive(session.match.id);
      io.to(roomCode).emit('game_state', publicState(session));
    });

    socket.on('roll_dice', () => {
      const { roomCode, playerId } = socket.data;
      const session = sessions.get(roomCode);
      if (!session?.engineState) return;
      const state = session.engineState;
      if (ludo.currentPlayer(state).playerId !== playerId) {
        return socket.emit('error_message', "It's not your turn.");
      }
      const result = ludo.applyRoll(state);
      io.to(roomCode).emit('dice_rolled', {
        roll: result.roll,
        movable: result.movable,
        autoPassed: result.autoPassed,
        by: playerId,
      });
      io.to(roomCode).emit('game_state', publicState(session));
    });

    socket.on('move_token', ({ tokenIndex }) => {
      const { roomCode, playerId } = socket.data;
      const session = sessions.get(roomCode);
      if (!session?.engineState) return;
      const state = session.engineState;
      if (ludo.currentPlayer(state).playerId !== playerId) {
        return socket.emit('error_message', "It's not your turn.");
      }
      try {
        const result = ludo.moveToken(state, tokenIndex);
        io.to(roomCode).emit('token_moved', {
          tokenIndex,
          captured: result.captured,
          state: publicState(session),
        });
        if (state.status === 'finished') {
          finalizeMatch(session, io, bot).catch((e) => console.error('finalizeMatch error:', e));
        }
      } catch (err) {
        socket.emit('error_message', err.message);
      }
    });

    socket.on('disconnect', () => {
      const { roomCode, playerId } = socket.data || {};
      if (!roomCode) return;
      const session = sessions.get(roomCode);
      if (session) {
        session.sockets.delete(playerId);
        io.to(roomCode).emit('lobby_update', {
          players: session.joinOrder.map((j) => ({ playerId: j.playerId, name: j.name, color: j.color })),
          canStart: session.joinOrder.length >= 2,
        });
      }
    });
  });
}

async function finalizeMatch(session, io, bot) {
  const state = session.engineState;
  const ranking = state.finishedOrder; // player_id order, winner first
  const match = session.match;
  const t = match.tournament_id ? tournamentService.getTournament(match.tournament_id) : null;
  const pointsTable = t ? tournamentService.pointsTableFor(t) : { win: 10, second: 6, third: 3, lose: 1 };

  try {
    matchService.recordResult(match.id, ranking, pointsTable);
  } catch (err) {
    console.error('Could not record result (likely duplicate):', err.message);
    return; // guard: never double-apply points
  }

  io.to(match.room_code).emit('game_over', {
    ranking: ranking.map((id) => ({ playerId: id, name: playerService.displayName(playerService.getPlayerById(id)) })),
  });

  if (!bot?.telegram) return;
  const names = ranking.map((id) => playerService.displayName(playerService.getPlayerById(id)));
  await bot.telegram
    .sendMessage(match.chat_id, `🏁 Match #${match.id} finished!\n\nResult: ${names.join(' > ')}\n\nScores updated automatically.`)
    .catch(() => {});

  if (t) {
    const progress = tournamentService.progressAfterMatch(t.id);
    if (progress?.finished) {
      const winner = playerService.getPlayerById(progress.winnerId);
      await bot.telegram
        .sendMessage(
          match.chat_id,
          `🎉🏆 *TOURNAMENT WINNER: ${playerService.displayName(winner)}!* 🏆🎉`,
          { parse_mode: 'Markdown' }
        )
        .catch(() => {});
    } else if (progress?.nextMatches) {
      for (const m of progress.nextMatches) {
        const mNames = m.player_ids.map((id) => playerService.displayName(playerService.getPlayerById(id))).join(' vs ');
        await bot.telegram
          .sendMessage(match.chat_id, `➡️ Next round — Match #${m.id}: ${mNames}\nRoom: ${m.room_code}`)
          .catch(() => {});
      }
    }
  }
}

module.exports = attachSocketServer;
