/**
 * Restricts a command to Telegram group admins/creators.
 * Usage: bot.command('start_tournament', isAdmin, handler)
 */
async function isAdmin(ctx, next) {
  try {
    if (ctx.chat.type === 'private') {
      return ctx.reply('This command only works inside a group.');
    }
    const member = await ctx.telegram.getChatMember(ctx.chat.id, ctx.from.id);
    if (member.status === 'administrator' || member.status === 'creator') {
      return next();
    }
    return ctx.reply('⛔ Only group admins can do this.');
  } catch (err) {
    console.error('isAdmin check failed:', err.message);
    return ctx.reply('Could not verify admin status. Try again.');
  }
}

module.exports = isAdmin;
