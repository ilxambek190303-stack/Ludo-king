const { Markup } = require('telegraf');
const { PUBLIC_URL } = require('../config/env');

function joinTournamentKeyboard(tournamentId) {
  return Markup.inlineKeyboard([
    [Markup.button.callback('✅ Join Tournament', `join_tournament:${tournamentId}`)],
    [Markup.button.callback('📋 Show Registered Players', `show_players:${tournamentId}`)],
  ]);
}

function adminStartKeyboard(tournamentId) {
  return Markup.inlineKeyboard([
    [Markup.button.callback('▶️ Start Tournament', `start_tournament:${tournamentId}`)],
  ]);
}

function openGameKeyboard(roomCode) {
  const url = `${PUBLIC_URL}/?room=${roomCode}`;
  return Markup.inlineKeyboard([[Markup.button.webApp('🎲 Open Ludo Game', url)]]);
}

function reportResultKeyboard(matchId) {
  return Markup.inlineKeyboard([[Markup.button.callback('📝 Report Result', `report_result:${matchId}`)]]);
}

module.exports = { joinTournamentKeyboard, adminStartKeyboard, openGameKeyboard, reportResultKeyboard };
