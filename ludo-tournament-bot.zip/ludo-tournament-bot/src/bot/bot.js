const { Telegraf } = require('telegraf');
const { BOT_TOKEN } = require('../config/env');

if (!BOT_TOKEN) {
  console.warn('⚠️  BOT_TOKEN is not set — the bot will not start. Copy .env.example to .env and fill it in.');
}

const bot = new Telegraf(BOT_TOKEN || 'invalid-token');

require('./commands/general')(bot);
require('./commands/tournament')(bot);
require('./commands/admin')(bot);
require('./commands/profile')(bot);

bot.catch((err, ctx) => {
  console.error(`Bot error for ${ctx.updateType}:`, err);
  ctx.reply('⚠️ Something went wrong handling that command.').catch(() => {});
});

module.exports = bot;
