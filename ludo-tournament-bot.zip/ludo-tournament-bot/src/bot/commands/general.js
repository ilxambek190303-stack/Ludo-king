const { openGameKeyboard } = require('../keyboards');
const { nanoid } = require('nanoid');
const matchService = require('../../services/matchService');
const playerService = require('../../services/playerService');

function register(bot) {
  bot.start((ctx) => {
    ctx.reply(
      '🎲 *Welcome to Ludo Tournament Bot!*\n\n' +
        'Add me to a group to run Ludo tournaments, or tap Play below to try a quick match.\n\n' +
        '*Group commands:*\n' +
        '/create_tournament — (admin) open registration\n' +
        '/join — join the open tournament\n' +
        '/players — show registered players\n' +
        '/start_tournament — (admin) begin matches\n' +
        '/standings — current leaderboard\n' +
        '/profile — your stats\n' +
        '/help — full command list',
      { parse_mode: 'Markdown' }
    );
  });

  bot.help((ctx) => {
    ctx.reply(
      '*Player commands*\n' +
        '/join — join the currently open tournament\n' +
        '/players — list registered players\n' +
        '/standings — leaderboard for this group\n' +
        '/profile — your personal stats\n' +
        '/history — recent match results\n\n' +
        '*Admin commands*\n' +
        '/create_tournament — open registration\n' +
        '/start_tournament — start matches\n' +
        '/stop_tournament — stop the current tournament\n' +
        '/restart_tournament — clear matches, reopen registration\n' +
        '/setscoring win second third lose — change point values\n' +
        '/addplayer <name> — add a player manually\n' +
        '/removeplayer @username — remove a player\n' +
        '/allplayers — view every player in this group\n' +
        '/matchhistory — full match history\n' +
        '/resetleaderboard — wipe all stats for this group\n' +
        '/tournamentstats — stats for the current/last tournament',
      { parse_mode: 'Markdown' }
    );
  });

  // Quick casual (non-tournament) match, for testing the game itself.
  bot.command('play', async (ctx) => {
    const chatId = ctx.chat.id;
    const player = playerService.getOrCreatePlayer(chatId, ctx.from);
    const match = matchService.createMatch({ chatId, tournamentId: null, playerIds: [player.id] });
    await ctx.reply(
      'Tap below to open the game. Share the room link with friends to add more players (2-4 total).',
      openGameKeyboard(match.room_code)
    );
  });
}

module.exports = register;
