const isAdmin = require('../middlewares/isAdmin');
const { joinTournamentKeyboard, adminStartKeyboard, openGameKeyboard } = require('../keyboards');
const tournamentService = require('../../services/tournamentService');
const playerService = require('../../services/playerService');
const matchService = require('../../services/matchService');
const scoreService = require('../../services/scoreService');

function formatPlayerList(players) {
  if (players.length === 0) return '_No players yet._';
  return players.map((p, i) => `${i + 1}. ${playerService.displayName(p)}`).join('\n');
}

function announceMatches(ctx, matches) {
  matches.forEach((m) => {
    const names = m.player_ids
      .map((id) => playerService.displayName(playerService.getPlayerById(id)))
      .join(' vs ');
    ctx.reply(
      `🎮 *New Match* (ID: ${m.id})\n${names}\n\n` +
        `Open the game below, then an admin reports the result with:\n` +
        `\`/result ${m.id} <finish order, winner first, space-separated @usernames>\``,
      { parse_mode: 'Markdown', ...openGameKeyboard(m.room_code) }
    );
  });
}

function register(bot) {
  bot.command('create_tournament', isAdmin, async (ctx) => {
    try {
      const t = tournamentService.createTournament(ctx.chat.id, ctx.from.id);
      await ctx.reply(
        `🏆 *New Ludo Tournament!*\n\nTap below to join. Admin can start once at least 2 players are in.`,
        { parse_mode: 'Markdown', ...joinTournamentKeyboard(t.id) }
      );
    } catch (err) {
      ctx.reply(`⚠️ ${err.message}`);
    }
  });

  bot.action(/join_tournament:(\d+)/, async (ctx) => {
    const tournamentId = parseInt(ctx.match[1], 10);
    try {
      const player = playerService.getOrCreatePlayer(ctx.chat.id, ctx.from);
      const list = tournamentService.joinTournament(tournamentId, player.id);
      await ctx.answerCbQuery('You joined the tournament!');
      await ctx.reply(`✅ ${playerService.displayName(player)} joined!\n\n*Registered players:*\n${formatPlayerList(list)}`, {
        parse_mode: 'Markdown',
      });
    } catch (err) {
      await ctx.answerCbQuery(err.message, { show_alert: true });
    }
  });

  bot.command('join', async (ctx) => {
    const t = tournamentService.getActiveTournament(ctx.chat.id);
    if (!t || t.status !== 'registration') return ctx.reply('There is no open tournament to join right now.');
    const player = playerService.getOrCreatePlayer(ctx.chat.id, ctx.from);
    const list = tournamentService.joinTournament(t.id, player.id);
    ctx.reply(`✅ ${playerService.displayName(player)} joined!\n\n*Registered players:*\n${formatPlayerList(list)}`, {
      parse_mode: 'Markdown',
    });
  });

  const showPlayers = async (ctx) => {
    const t = tournamentService.getActiveTournament(ctx.chat.id);
    if (!t) return ctx.reply('No tournament is currently open.');
    const list = tournamentService.listRegistered(t.id);
    ctx.reply(`*Registered players (${list.length}):*\n${formatPlayerList(list)}`, { parse_mode: 'Markdown' });
  };
  bot.command('players', showPlayers);
  bot.action(/show_players:(\d+)/, async (ctx) => {
    await ctx.answerCbQuery();
    showPlayers(ctx);
  });

  const doStart = async (ctx, tournamentId) => {
    try {
      const matches = tournamentService.startTournament(tournamentId);
      await ctx.reply('🏁 Tournament started! Round 1 matches:');
      announceMatches(ctx, matches);
    } catch (err) {
      ctx.reply(`⚠️ ${err.message}`);
    }
  };

  bot.command('start_tournament', isAdmin, async (ctx) => {
    const t = tournamentService.getActiveTournament(ctx.chat.id);
    if (!t) return ctx.reply('No tournament to start. Use /create_tournament first.');
    doStart(ctx, t.id);
  });

  bot.action(/start_tournament:(\d+)/, isAdmin, async (ctx) => {
    await ctx.answerCbQuery();
    doStart(ctx, parseInt(ctx.match[1], 10));
  });

  bot.command('standings', (ctx) => renderStandings(ctx));
  bot.command('leaderboard', (ctx) => renderStandings(ctx));

  function renderStandings(ctx) {
    const players = playerService.listPlayers(ctx.chat.id).filter((p) => p.games_played > 0 || p.points > 0);
    if (players.length === 0) return ctx.reply('No games played yet in this group.');
    const medals = ['🥇', '🥈', '🥉'];
    let text = '🏆 *LUDO TOURNAMENT LEADERBOARD*\n\n';
    players.slice(0, 10).forEach((p, i) => {
      const medal = medals[i] || `${i + 1}️⃣`;
      text += `${medal} ${playerService.displayName(p)} — ${p.points} points\n`;
    });
    const totals = players.reduce(
      (acc, p) => {
        acc.games += p.games_played;
        acc.wins += p.wins;
        acc.losses += p.losses;
        acc.points += p.points;
        return acc;
      },
      { games: 0, wins: 0, losses: 0, points: 0 }
    );
    text +=
      `\n📊 *Group totals*\n` +
      `Games played: ${totals.games}\n` +
      `Wins: ${totals.wins} · Losses: ${totals.losses}\n` +
      `Total points: ${totals.points}`;
    ctx.reply(text, { parse_mode: 'Markdown' });
  }

  bot.command('history', (ctx) => {
    const rows = matchService.history(ctx.chat.id, 10);
    if (rows.length === 0) return ctx.reply('No finished matches yet.');
    let text = '📜 *Recent matches*\n\n';
    rows.forEach((m) => {
      const names = m.ranking.map((id) => playerService.displayName(playerService.getPlayerById(id))).join(' > ');
      text += `Match ${m.id}: ${names}\n`;
    });
    ctx.reply(text, { parse_mode: 'Markdown' });
  });

  // /result <matchId> @p1 @p2 @p3 @p4   (winner first)
  bot.command('result', isAdmin, async (ctx) => {
    const parts = ctx.message.text.trim().split(/\s+/).slice(1);
    if (parts.length < 3) {
      return ctx.reply('Usage: /result <matchId> @winner @second @third... (winner first)');
    }
    const matchId = parseInt(parts[0], 10);
    const usernames = parts.slice(1).map((u) => u.replace('@', '').toLowerCase());

    const match = matchService.getMatch(matchId);
    if (!match) return ctx.reply('Match not found.');

    const candidates = match.player_ids.map((id) => playerService.getPlayerById(id));
    const ranking = [];
    for (const uname of usernames) {
      const found = candidates.find((p) => (p.username || '').toLowerCase() === uname);
      if (!found) return ctx.reply(`Could not match @${uname} to a player in match ${matchId}.`);
      ranking.push(found.id);
    }

    try {
      const t = match.tournament_id ? tournamentService.getTournament(match.tournament_id) : null;
      const pointsTable = t
        ? tournamentService.pointsTableFor(t)
        : { win: 10, second: 6, third: 3, lose: 1 };
      matchService.recordResult(matchId, ranking, pointsTable);
      await ctx.reply(`✅ Result recorded for match ${matchId}.`);
      renderStandings(ctx);

      if (t) {
        const progress = tournamentService.progressAfterMatch(t.id);
        if (progress?.finished) {
          const winner = playerService.getPlayerById(progress.winnerId);
          await ctx.reply(
            `🎉🏆 *TOURNAMENT WINNER: ${playerService.displayName(winner)}!* 🏆🎉\n\nCongratulations!`,
            { parse_mode: 'Markdown' }
          );
        } else if (progress?.nextMatches) {
          await ctx.reply('➡️ Next round:');
          announceMatches(ctx, progress.nextMatches);
        }
      }
    } catch (err) {
      ctx.reply(`⚠️ ${err.message}`);
    }
  });
}

module.exports = register;
