const isAdmin = require('../middlewares/isAdmin');
const tournamentService = require('../../services/tournamentService');
const playerService = require('../../services/playerService');
const matchService = require('../../services/matchService');
const scoreService = require('../../services/scoreService');

function register(bot) {
  bot.command('stop_tournament', isAdmin, (ctx) => {
    const t = tournamentService.getActiveTournament(ctx.chat.id);
    if (!t) return ctx.reply('No active tournament.');
    tournamentService.stopTournament(t.id);
    ctx.reply('🛑 Tournament stopped.');
  });

  bot.command('restart_tournament', isAdmin, (ctx) => {
    const t = tournamentService.getActiveTournament(ctx.chat.id);
    if (!t) return ctx.reply('No tournament to restart.');
    tournamentService.restartTournament(t.id);
    ctx.reply('🔄 Tournament reset. Registration is open again — players can /join.');
  });

  bot.command('removeplayer', isAdmin, (ctx) => {
    const uname = ctx.message.text.split(/\s+/)[1];
    if (!uname) return ctx.reply('Usage: /removeplayer @username');
    const clean = uname.replace('@', '');
    const players = playerService.listPlayers(ctx.chat.id);
    const target = players.find((p) => (p.username || '').toLowerCase() === clean.toLowerCase());
    if (!target) return ctx.reply('Player not found.');
    playerService.removePlayer(ctx.chat.id, target.telegram_id);
    ctx.reply(`Removed ${playerService.displayName(target)} from this group's records.`);
  });

  bot.command('addplayer', isAdmin, (ctx) => {
    const name = ctx.message.text.split(/\s+/).slice(1).join(' ');
    if (!name) return ctx.reply('Usage: /addplayer <name>');
    // Manual players get a negative synthetic telegram_id so they never collide with real accounts.
    const fakeId = -Math.floor(Math.random() * 1e9) - 1;
    const player = playerService.addManualPlayer(ctx.chat.id, fakeId, name);
    ctx.reply(`➕ Added manual player: ${playerService.displayName(player)} (id ${player.id})`);
  });

  bot.command('setscoring', isAdmin, (ctx) => {
    const parts = ctx.message.text.trim().split(/\s+/).slice(1).map(Number);
    if (parts.length !== 4 || parts.some(Number.isNaN)) {
      return ctx.reply('Usage: /setscoring <win> <second> <third> <lose>\nExample: /setscoring 10 6 3 1');
    }
    const t = tournamentService.getActiveTournament(ctx.chat.id);
    if (!t) return ctx.reply('No open/active tournament to apply scoring to. Create one first.');
    const [win, second, third, lose] = parts;
    tournamentService.setPointValues(t.id, { win, second, third, lose });
    ctx.reply(`✅ Scoring updated: Win ${win} · 2nd ${second} · 3rd ${third} · Lose ${lose}`);
  });

  bot.command('allplayers', isAdmin, (ctx) => {
    const players = playerService.listPlayers(ctx.chat.id);
    if (players.length === 0) return ctx.reply('No players recorded yet.');
    let text = `👥 *All players (${players.length})*\n\n`;
    players.forEach((p) => {
      text += `${playerService.displayName(p)} — ${p.points} pts, ${p.games_played} games, ${scoreService.winRate(p)}% WR\n`;
    });
    ctx.reply(text, { parse_mode: 'Markdown' });
  });

  bot.command('matchhistory', isAdmin, (ctx) => {
    const rows = matchService.history(ctx.chat.id, 30);
    if (rows.length === 0) return ctx.reply('No finished matches yet.');
    let text = '📜 *Full match history*\n\n';
    rows.forEach((m) => {
      const names = m.ranking.map((id) => playerService.displayName(playerService.getPlayerById(id))).join(' > ');
      text += `#${m.id} (${m.finished_at}): ${names}\n`;
    });
    ctx.reply(text, { parse_mode: 'Markdown' });
  });

  bot.command('resetleaderboard', isAdmin, (ctx) => {
    playerService.resetLeaderboard(ctx.chat.id);
    ctx.reply('🧹 Leaderboard reset for this group. All stats are back to zero.');
  });

  bot.command('tournamentstats', isAdmin, (ctx) => {
    const t = tournamentService.getActiveTournament(ctx.chat.id) || tournamentService.history(ctx.chat.id, 1)[0];
    if (!t) return ctx.reply('No tournament has been created in this group yet.');
    const registered = tournamentService.listRegistered(t.id);
    const matches = matchService.tournamentMatches(t.id);
    const finished = matches.filter((m) => m.status === 'finished');
    let text =
      `📊 *Tournament #${t.id} stats*\n` +
      `Status: ${t.status}\n` +
      `Players: ${registered.length}\n` +
      `Matches: ${matches.length} (${finished.length} finished)\n` +
      `Scoring: Win ${t.win_points} · 2nd ${t.second_points} · 3rd ${t.third_points} · Lose ${t.lose_points}\n`;
    if (t.winner_player_id) {
      text += `Winner: ${playerService.displayName(playerService.getPlayerById(t.winner_player_id))}\n`;
    }
    ctx.reply(text, { parse_mode: 'Markdown' });
  });
}

module.exports = register;
