const playerService = require('../../services/playerService');
const scoreService = require('../../services/scoreService');

function register(bot) {
  bot.command('profile', (ctx) => {
    if (ctx.chat.type === 'private') {
      return ctx.reply('Open /profile inside a group to see your stats for that group.');
    }
    const player = playerService.getOrCreatePlayer(ctx.chat.id, ctx.from);
    const text =
      `👤 *${playerService.displayName(player)}*\n\n` +
      `Total games: ${player.games_played}\n` +
      `Wins: ${player.wins}\n` +
      `Losses: ${player.losses}\n` +
      `Points: ${player.points}\n` +
      `Tournament wins: ${player.tournament_wins}\n` +
      `Win rate: ${scoreService.winRate(player)}%`;
    ctx.reply(text, { parse_mode: 'Markdown' });
  });
}

module.exports = register;
